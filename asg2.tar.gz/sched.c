// Name: Ng Xuan Yi (Xuan Yi Ng)
// CPSC 3220 Assignment 2

// To compile the file, first run: gcc sched.c -o sched
// Run Command: ./sched -prio < in1 > out1
// Run Command: ./sched -custom < in1 > out1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>

typedef struct task{
    int task_id; // Alphabetic tid
    int arrival_time;
    int service_time;
    int remaining_time;
    int completion_time;
    int response_time;
    int wait_time;
    int priority;
    bool task_is_completed;
    struct task *next;
} Task;

// Priority Helper Function Prototypes
int compareTasks(const void *a, const void *b);
Task *selectNextTask(Task taskList[], int taskCount, int currentTime);
void executeTask(Task *task, Task **head, int currentTime, int *numTasksCompleted);
void writeOutput(const char *outputFilename, bool priorityAlgo, Task **head, Task taskList[], int taskCount);
int compareByServiceTime(const void *a, const void *b);
int compareByTaskId(const void *a, const void *b);
// Custom Scheduling Helper Function Prototypes
void customSchedule(Task taskList[], int taskCount, Task **head, int *numTasksCompleted);
void executeTaskForOneUnit(Task *task, Task **head, int currentTime, int *numTasksCompleted);
void addTaskToLinkedList(Task **head, Task *task, int currentTime);
Task *selectNextTaskFromQueue(Task taskList[], int taskCount, int currentTime, Task *currentTask);
void addTaskToQueue(Task **queue, Task *task);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: programName -prio|-custom < inputFilename > outputFilename\n");
        return 1;
    }

    // Create an ArrayList to store the tasks read from the input file, assuming a max of 26 tasks
    Task taskList[26];
    Task *head = NULL;
    int taskCount = 0;
    // Starting taskID is Y
    char taskID = 'Y';

    // Read the 3 numbers row by row, so long as not EOF
    int arrivalTime, serviceTime, processPriority;
    while (scanf("%d %d %d", &arrivalTime, &serviceTime, &processPriority) == 3) {
        taskList[taskCount].task_id = taskID;
        taskList[taskCount].arrival_time = arrivalTime;
        taskList[taskCount].priority = processPriority;
        taskList[taskCount].service_time = serviceTime;
        // At the start, remaining = service
        taskList[taskCount].remaining_time = serviceTime;
        taskList[taskCount].task_is_completed = false;

        // Update the new TaskID
        taskID = (taskID == 'Z' ? 'A' : taskID + 1);
        taskCount += 1;
    }

    // Reorder the tasks in ascending arrival times
    qsort(taskList, taskCount, sizeof(Task), compareTasks);

    // Select algo based on user input
    if (strcmp(argv[1], "-prio") == 0) {
        // Priority-based; Execute until there are no more tasks
        int numTasksCompleted = 0;
        int currentTime = 0;
        
        while (numTasksCompleted < taskCount) {
            // Retrieve the next task based on priority, then service time
            Task *currTask = selectNextTask(taskList, taskCount, currentTime);
            if (currTask != NULL) {
                executeTask(currTask, &head, currentTime, &numTasksCompleted);
            }
            // Increment the current time
            currentTime += 1;
        }

        // After getting LL, print the output
        writeOutput(argv[3], true, &head, taskList, taskCount);
    }
    else if (strcmp(argv[1], "-custom") == 0) {
        // Custom-based; Current task executes for 1 clock cycle only
        int numTasksCompleted = 0;
        customSchedule(taskList, taskCount, &head, &numTasksCompleted);

        // Write output
        writeOutput(argv[3], false, &head, taskList, taskCount);
    }
    else {
        // Erroneous input
        fprintf(stderr, "Invalid command. Use either -prio for Priority-based or -custom for Custom-based scheduling.\n");
        return 1;
    }

    return 0;
}



int compareTasks(const void *a, const void *b) {
    Task *taskA = (Task *)a;
    Task *taskB = (Task *)b;
    return (taskA->arrival_time - taskB->arrival_time);
}

Task *selectNextTask(Task taskList[], int taskCount, int currentTime) {
    // Find the task with the highest priority, i.e., lowest number
    Task *nextTask = NULL;
    int highestPriority = INT_MAX;
    int shortestServiceTime = INT_MAX;

    // Loop through all the tasks
    for (int i = 0; i < taskCount; i += 1) {
        if (taskList[i].arrival_time <= currentTime && !taskList[i].task_is_completed) {
            // Check for highest priority and then shortest service time
            if (taskList[i].priority < highestPriority || 
               (taskList[i].priority == highestPriority && taskList[i].service_time < shortestServiceTime)) {
                // Update with the task
                highestPriority = taskList[i].priority;
                shortestServiceTime = taskList[i].service_time;
                nextTask = &taskList[i];
            }
        }
    }
    return nextTask;
}

void executeTask(Task *task, Task **head, int currentTime, int *numTasksCompleted) {
    // Check if task is completed
    if (!task->task_is_completed) {
        // Create a snapshot of the task's state after one time unit of execution
        Task *snapshot = malloc(sizeof(Task));
        if (!snapshot) {
            fprintf(stderr, "Memory allocation failed for task snapshot.\n");
            return;
        }
        *snapshot = *task;
        snapshot->next = NULL;

        // Add the snapshot to the linked list
        if (*head == NULL) {
            *head = snapshot;
        } else {
            Task *current = *head;
            while (current->next != NULL) {
                current = current->next;
            }
            current->next = snapshot;
        }

        // Continue executing task
        task->remaining_time -= 1;

        if (task->remaining_time == 0) {
            // Task execution is complete
            task->completion_time = currentTime + 1;

            // Calculate and Update Tasks' stats
            task->response_time = task->completion_time - task->arrival_time;
            task->wait_time = task->response_time - task->service_time;
            task->task_is_completed = true;
            (*numTasksCompleted) += 1;
        }

        
    }
}

// Comparison function to sort by service_time
int compareByServiceTime(const void *a, const void *b) {
    Task *taskA = (Task *)a;
    Task *taskB = (Task *)b;
    return taskA->service_time - taskB->service_time;
}

// Comparison function to sort by task_id
int compareByTaskId(const void *a, const void *b) {
    Task *taskA = (Task *)a;
    Task *taskB = (Task *)b;
    return taskA->task_id - taskB->task_id;
}

void writeOutput(const char *outputFilename, bool priorityAlgo, Task **head, Task taskList[], int taskCount) {
    // Using output redirection
    FILE *output = stdout;

    // Write Headers for File
    if (priorityAlgo) {
        // Priority Algo
        fprintf(output, "Priority scheduling results\n\n");
    }
    else {
        // Custom Algo
        fprintf(output, "Custom(preemptive) scheduling results\n\n");
    }
    fprintf(output, "%-5s %-7s %-9s %-18s\n", "time", "cpu", "priority", "ready_queue (tid/rst)");
    fprintf(output, "--------------------------------------------------\n");

    // Print Results in Linked List
    int currentTime = 0;
    for (Task *current = *head; current != NULL; current = current->next) {
        while (currentTime < current->arrival_time) {
            // Current time is Idle
            fprintf(output, "%-5d %-8s %-10s %-20s\n", currentTime, "  ", "  ", "--");
            currentTime += 1;
        }
        
        // Determine the values to be printed
        char cpuOutput[100];
        sprintf(cpuOutput, "%c%d", current->task_id, current->remaining_time);

        // Check if there is a ready queue by searching linked list until diff task
        Task *nextTask = current;
        char readyQueue[150];
        while (nextTask != NULL && nextTask->task_id == current->task_id) {
            nextTask = nextTask->next;
        }

        if (nextTask == NULL) {
            // No ready queue
            sprintf(readyQueue, "--");
        }
        else if (nextTask->arrival_time == current->arrival_time) {
            // Have queue
            sprintf(readyQueue, "%c%d %d", nextTask->task_id, nextTask->remaining_time, nextTask->priority);
            nextTask = nextTask->next;
        }
        else {
            // No queue but task is not NULL
            sprintf(readyQueue, "--");
        }
        fprintf(output, "%-5d %-7s %-9d %-18s\n", currentTime, cpuOutput, current->priority, readyQueue);

        // Update the details
        currentTime += 1;
        current->remaining_time -= 1;

    }
    fprintf(output, "\n\n\n");

    // Sort the Tasks by TID in ascending order for Task Summary Table
    qsort(taskList, taskCount, sizeof(Task), compareByTaskId);

    // Print the Task Summary Table
    fprintf(output, "%-6s %-9s %-16s %-18s %-17s %-12s %-10s\n", "tid", "prio", "arrival_time", "service_time", "completion_time", "resp_time", "wait_time");
    fprintf(output, "--------------------------------------------------------------------------------------------\n");
    
    for (int i = 0; i < taskCount; i += 1) {
        // Calculate the Response Time & Wait Time
        taskList[i].response_time = taskList[i].completion_time - taskList[i].arrival_time;
        taskList[i].wait_time = taskList[i].response_time - taskList[i].service_time;

        char taskSummary[100];
        if (priorityAlgo) {
            fprintf(output, "%-6c %-9d %-16d %-18d %-17d %-12d %-10d\n", 
            (char) taskList[i].task_id, taskList[i].priority, taskList[i].arrival_time, 
            taskList[i].service_time, taskList[i].completion_time, 
            taskList[i].response_time, taskList[i].wait_time);
        }
        else {
            fprintf(output, "%-6c %-9d %-16d %-18d %-17d %-12d %-10d\n", 
            (char) taskList[i].task_id, (taskList[i].priority - taskList[i].service_time + 1), taskList[i].arrival_time, 
            taskList[i].service_time, taskList[i].completion_time, 
            taskList[i].response_time, taskList[i].wait_time);
        }
        
    }
    fprintf(output, "\n\n\n");

    // Sort the Tasks by service time in ascending order for last table
    qsort(taskList, taskCount, sizeof(Task), compareByServiceTime);

    // Print the Service-Wait Time Pairs in ascending service time
    fprintf(output, "service_time   wait_time  \n");
    fprintf(output, "-------------  -----------\n");

    for (int i = 0; i < taskCount; i += 1) {
        char temp[50];
        fprintf(output, "  %-13d %-11d\n", taskList[i].service_time, taskList[i].wait_time);
    }

}

void customSchedule(Task taskList[], int taskCount, Task **head, int *numTasksCompleted) {
    int currentTime = 0;
    Task *currentTask = NULL;

    while (*numTasksCompleted < taskCount) {
        currentTask = selectNextTaskFromQueue(taskList, taskCount, currentTime, currentTask);

        // Execute any tasks for one time unit
        if (currentTask) {
            executeTaskForOneUnit(currentTask, head, currentTime, numTasksCompleted);
        }
        currentTime += 1;
    }
}

Task *selectNextTaskFromQueue(Task taskList[], int taskCount, int currentTime, Task *currentTask) {
    Task *nextTask = NULL;
    int highestPriority = INT_MAX;
    int shortestServiceTime = INT_MAX;

    for (int i = 0; i < taskCount; i += 1) {
        // Check if task is uncompleted and arrived
        if (taskList[i].arrival_time <= currentTime && !taskList[i].task_is_completed) {
            // Check based on priority then service time
            if ((taskList[i].priority < highestPriority) ||
                (taskList[i].priority == highestPriority && taskList[i].service_time < shortestServiceTime)) {
                highestPriority = taskList[i].priority;
                shortestServiceTime = taskList[i].service_time;
                nextTask = &taskList[i];
            }
        }
        
    }

    return nextTask;
}


void executeTaskForOneUnit(Task *task, Task **head, int currentTime, int *numTasksCompleted) {
    // Check if task is completed
    if (task->remaining_time > 0) {
        // Take a snapshot before executing the task
        Task *snapshot = malloc(sizeof(Task));
        if (!snapshot) {
            fprintf(stderr, "Memory allocation failed for task snapshot.\n");
            return;
        }
        *snapshot = *task;
        snapshot->next = NULL;

        // Add the snapshot to the linked list
        if (*head == NULL) {
            *head = snapshot;
        } else {
            Task *last = *head;
            while (last->next != NULL) {
                last = last->next;
            }
            last->next = snapshot;
        }

        // Execute the task
        task->remaining_time -= 1;
        if (task->remaining_time == 0) {
            // Task execution is complete
            task->completion_time = currentTime + 1;

            // Update and mark task
            task->task_is_completed = true;
            (*numTasksCompleted) += 1;
        } else {
            // Increase the priority if the task has not completed
            task->priority += 1;
        }
    }
}

void addTaskToLinkedList(Task **head, Task *task, int currentTime) {
    // Adding current state of task (may not be completed) to queue
    Task *snapshot = malloc(sizeof(Task));
    if (snapshot == NULL) {
        perror("Failed to allocate memory for snapshot.");
        return;
    }

    // Copy the task's current state
    *snapshot = *task;
    snapshot->next = NULL;

    if (*head == NULL) {
        *head = snapshot;
    } else {
        Task *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = snapshot;
    }
}

void addTaskToQueue(Task **queue, Task *task) {
    // Assume task is appended at the end of queue
    task->next = NULL;
    if (*queue == NULL) {
        *queue = task;
    } else {
        Task *temp = *queue;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = task;
    }
}

